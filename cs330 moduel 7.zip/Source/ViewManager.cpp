///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// Camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// These variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// Controls the camera movement speed
	float gMovementSpeedScale = 1.0f;

	// False uses perspective projection
	// True uses orthographic projection
	bool bOrthographicProjection = false;

	/***********************************************************
	 *  Mouse_Scroll_Callback()
	 *
	 *  Changes the camera travel speed when the mouse wheel
	 *  is scrolled.
	 ***********************************************************/
	void Mouse_Scroll_Callback(
		GLFWwindow* window,
		double xOffset,
		double yOffset)
	{
		// Scroll upward to increase movement speed
		if (yOffset > 0.0)
		{
			gMovementSpeedScale += 0.25f;
		}

		// Scroll downward to decrease movement speed
		if (yOffset < 0.0)
		{
			gMovementSpeedScale -= 0.25f;
		}

		// Keep the speed within a reasonable range
		if (gMovementSpeedScale < 0.25f)
		{
			gMovementSpeedScale = 0.25f;
		}

		if (gMovementSpeedScale > 4.0f)
		{
			gMovementSpeedScale = 4.0f;
		}
	}
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// Initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();

	// Default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// Free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// Try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}

	glfwMakeContextCurrent(window);

	// Capture the cursor for smooth camera movement
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// Receive mouse movement events
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// Receive mouse-wheel events
	glfwSetScrollCallback(
		window,
		Mouse_Scroll_Callback);

	// Enable blending for transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	// Save the first mouse position to prevent a sudden jump
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	// Calculate how far the mouse moved
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// Save the current mouse position
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Rotate the camera based on mouse movement
	if (NULL != g_pCamera)
	{
		g_pCamera->ProcessMouseMovement(
			xOffset,
			yOffset);
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Exit if the window is invalid
	if (NULL == m_pWindow)
	{
		return;
	}

	// Close the window when Escape is pressed
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	// Exit if the camera is invalid
	if (NULL == g_pCamera)
	{
		return;
	}

	// Apply the mouse-wheel speed setting
	float adjustedDeltaTime =
		gDeltaTime * gMovementSpeedScale;

	// W moves forward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			adjustedDeltaTime);
	}

	// S moves backward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			adjustedDeltaTime);
	}

	// A moves left
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			adjustedDeltaTime);
	}

	// D moves right
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			adjustedDeltaTime);
	}

	// Speed used for vertical movement
	float verticalMovementSpeed =
		2.5f * adjustedDeltaTime;

	// Q moves upward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position +=
			g_pCamera->Up * verticalMovementSpeed;
	}

	// E moves downward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position -=
			g_pCamera->Up * verticalMovementSpeed;
	}

	// P switches to perspective projection
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// O switches to orthographic projection
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method prepares the view and projection matrices
 *  used to display the 3D scene.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// Calculate the time between frames
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime =
		currentFrame - gLastFrame;

	gLastFrame =
		currentFrame;

	// Process keyboard input
	ProcessKeyboardEvents();

	// Get the camera view matrix
	view =
		g_pCamera->GetViewMatrix();

	// Use orthographic projection when O is selected
	if (bOrthographicProjection == true)
	{
		float orthoSize = 10.0f;
		float aspectRatio =
			static_cast<float>(WINDOW_WIDTH) /
			static_cast<float>(WINDOW_HEIGHT);

		projection = glm::ortho(
			-orthoSize * aspectRatio,
			orthoSize * aspectRatio,
			-orthoSize,
			orthoSize,
			0.1f,
			100.0f);
	}
	else
	{
		// Use perspective projection when P is selected
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			static_cast<GLfloat>(WINDOW_WIDTH) /
			static_cast<GLfloat>(WINDOW_HEIGHT),
			0.1f,
			100.0f);
	}

	// Pass the view information into the shader
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		m_pShaderManager->setVec3Value(
			"viewPosition",
			g_pCamera->Position);
	}
}